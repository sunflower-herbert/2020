#pragma once
#include<iostream>
#include<vector>
using namespace std;
struct Base{
    string name;
    virtual void spawn(){}
};
struct _base{
    string name;
    virtual void use(){}
};
vector<Base*>base_vector;
template<class T>
void pointer2(T* t);