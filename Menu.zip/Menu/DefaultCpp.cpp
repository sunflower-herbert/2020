#include"Class.cpp"
    struct default_son:public _base{
        default_son(){
            //name="...";
        }
        void use(){
            //...
        }
    };
    //...
    struct default_base:public Base{
        vector<_base*> vec;
        default_base(){
            //name="...";
            vec.push_back(new(default_son));
            //...
        }
        ~default_base(){
            for(int i=0;i<vec.size();i++)
                delete vec[i];
        }
        void spawn(){
            //...
            pointer2(this);
        }
    };