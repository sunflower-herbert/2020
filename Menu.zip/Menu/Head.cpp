#pragma once
#include<iostream>
#include"NewClass.cpp"
using namespace std;