#include"Head.cpp"
#include"VectorSet.cpp"
#include"Pointer1.cpp"
#include"Pointer2.cpp"
int main(){
    vector_set();
    printf("\33[2J\33[0;0H");
    // default_base db;
    // db.spawn();
    while(1){
        pointer1();
    }
    //...
}