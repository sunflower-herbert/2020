#include"Head.cpp"
void pointer1(){
    cout<<"->";
    string word;
    cin>>word;
    if(word=="~")
        exit(0);
    bool code=1;
    for(int i=0;i<base_vector.size();i++){
        if(word==base_vector[i]->name){
            base_vector[i]->spawn();
            code=0;
        }
    }
    if(code)
        cout<<"Command not found"<<endl;
}