#include"Head.cpp"
template<class T>
void pointer2(T* t){
while(1){
    cout<<"=>";
    string word;
    cin>>word;
    if(word=="~")
        return;
    bool code=1;
        for(int i=0;i<t->vec.size();i++){
            if(word==t->vec[i]->name){
                t->vec[i]->use();
                code=0;
            }
        }
    if(code)
        cout<<"command not found"<<endl;
    }
}