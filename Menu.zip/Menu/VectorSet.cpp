#include"Head.cpp"
void vector_set(){
    //Add Your Base Class Here!
    //eg.base_vector.push_back(new(base));
    base_vector.push_back(new(default_base));
}